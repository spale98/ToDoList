class ParameterTypeError extends Error {}

class ValidationError extends Error {}